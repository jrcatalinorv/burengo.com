<?php
function softTrim($text, $count, $wrapText='...'){
    if(strlen($text)>$count){
        preg_match('/^.{0,' . $count . '}(?:.*?)\b/siu', $text, $matches);
        $text = $matches[0];
    }else{
        $wrapText = '';
    }
    return $text . $wrapText;
}


function convert($id){
	switch($id){
		case 0: return ""; break;
		case 1: return " x día"; break;
		case 2: return " x Noche"; break;
		case 3: return " x Hora"; break;
		case 4: return " - Semanal"; break;
		case 5: return " - Mensual"; break;
		default: return ""; break;
	}
}

 

?>

