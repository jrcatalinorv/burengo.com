<?php
 define('COUNTRY_CODE', 'do');
?>

